
//implementing the Remote Interface

public class ImplTellTheTime implements baseChg {
	// implementing the interface methods
	public String baseChg(String str) {
		String st = "";
		int dec = Integer.parseInt(str);
		st += "Decimal of " + dec + " in Binary is " + Integer.toBinaryString(dec);
		st += "\nDecimal of " + dec + " in Octal is " + Integer.toOctalString(dec);
		st += "\nDecimal of " + dec + " in Hex is " + Integer.toHexString(dec);
		return st;

	}

}
