import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Client {
	private Client() {
	}

	public static void main(String[] args) {
		try {
			// Getting the registry
			Registry registry = LocateRegistry.getRegistry(null);
			// Looking up the registry for the remote object
			baseChg ttt = (baseChg) registry.lookup("baseChg");
			// Calling the remote method using the obtained object
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			System.out.print("Enter Decimal Number : ");
			String str = "";
			while (!(str = br.readLine()).equals("exit")) {
				System.out.println(ttt.baseChg(str));
				System.out.print("Enter Decimal Number : ");
			}
		} catch (Exception e) {
			System.err.println("Client exception:" + e.toString());
			e.printStackTrace();
		}
	}
}
