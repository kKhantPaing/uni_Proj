import java.rmi.Remote;
import java.rmi.RemoteException;

//Creating Remote Interface for out application
public interface baseChg extends Remote {
	String baseChg(String str) throws RemoteException;
}
